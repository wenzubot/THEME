//credit By Limzzzhama 
//no hapus credit ketauan hapus hitam//

module.exports = {
  domain: "http://socialluxeofficial.pteroweb.my.id", // Ubah jadi Domain panel Mu !!!
  port: "2906" // Ubah Jadi Port Panel Mu !!!
};